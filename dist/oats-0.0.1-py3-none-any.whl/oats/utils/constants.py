
# Protected gene prefixes that shouldn't appear anywhere in any gene names.
REFGEN_V3_TAG = "refgen_v3="
REFGEN_V4_TAG = "refgen_v3="
NCBI_TAG = "ncbi="
UNIPROT_TAG = "uniprot="