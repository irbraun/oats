def thingy(s):
	print(s)
