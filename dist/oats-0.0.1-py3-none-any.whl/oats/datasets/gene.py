



class Gene:

	def __init__(self, names, species):
		self.names = names
		self.species = species